package test;

import javax.vecmath.Vector3d;

import simbad.sim.BallAgent;

public class Bullets extends BallAgent{


    public Bullets(Vector3d pos, String name,float  radius) {
    	super(pos, name, radius);
    	
    }
    

	public void initBehavior() {}
	
	public void performBehavior() {	
		System.out.println("ok");
	}
	
}
