package test;

import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;

import simbad.sim.Agent;
import simbad.sim.RangeSensorBelt;
import simbad.sim.RobotFactory;

public class Zombie extends Agent {

	private Character cible;
	boolean test = false;
	private int power;
	RangeSensorBelt sonars;
	private MyEnv env;
	private boolean isDead;
	
	public Zombie(Vector3d pos, String name, Character cible, MyEnv env) {
		super(pos, name);
		this.env = env;
		setColor(new Color3f(255, 0, 0));
		this.cible = cible;
		setCanBeTraversed(false);
		sonars = RobotFactory.addBumperBeltSensor(this, 16);
		power = 10;
		isDead = false;
	}
	
	public void initBehavior() {}
	
	public void performBehavior() {
		
		boolean test = true;
		
		
		System.out.println("Var : " + isDead);
		
		this.isDead = true;
		
		
		setCanBeTraversed(false);
		Point3d ciblePos = new Point3d();
		cible.getCoords(ciblePos);
		double cibleX = ciblePos.getX();
		double cibleZ = ciblePos.getZ();
		
		Point3d myPos = new Point3d();
		getCoords(myPos);
		double myPosX = myPos.getX();
		double myPosZ = myPos.getZ();

		for(int i = 0; i < sonars.getNumSensors(); i++) {
			if(sonars.hasHit(i)) {
				rotateY(-(sonars.getSensorAngle(i)));
				setTranslationalVelocity(3);
				this.isDead = true;
				env.testRound();
				test = false;
			}
		}
		if(test) {
			this.isDead = true;
			setTranslationalVelocity(0);
			if(cibleX-0.3 > myPosX) {
				if     (cibleZ-0.3 > myPosZ) translateTo(new Vector3d(+0.1, 0, +0.1));
				else if(cibleZ+0.3 < myPosZ) translateTo(new Vector3d(+0.1, 0, -0.1));
				else                         translateTo(new Vector3d(+0.1, 0,  0  ));
			}
			else if(cibleX+0.3 < myPosX) {
				if     (cibleZ-0.3 > myPosZ) translateTo(new Vector3d(-0.1, 0, +0.1));
				else if(cibleZ+0.3 < myPosZ) translateTo(new Vector3d(-0.1, 0, -0.1));
				else                         translateTo(new Vector3d(-0.1, 0,  0  ));
			}
			else {
				if     (cibleZ-0.3 > myPosZ) translateTo(new Vector3d(0, 0, +0.1));
				else if(cibleZ+0.3 < myPosZ) translateTo(new Vector3d(0, 0, -0.1));
				else                         translateTo(new Vector3d(0, 0,  0  ));
			}
		}
	}
	
}
