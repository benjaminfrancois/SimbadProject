package test;

import simbad.gui.Simbad;
import simbad.sim.Simulator;

public class DeadOps {
	
	private Simbad frame;
	private int round = 0;
	
	public DeadOps() {
		upRound();
	}
	
	public void upRound()
	{
		round++;
		frame = null;
		frame = new Simbad(new MyEnv(round, this), false);
		frame.start(new MyEnv(round, this));
	}
	
	public Simulator getSimulator() { return frame.getSimulator(); }
	
	public static void main(String[] args) {
		new DeadOps();
	}
}