package test;

import java.util.ArrayList;
import java.util.Objects;

import javax.vecmath.Vector3d;
import simbad.sim.EnvironmentDescription;
import simbad.sim.Simulator;

public class MyEnv extends EnvironmentDescription {

	private DeadOps controller;
	
	public MyEnv(int round, DeadOps controller) {
		
		this.controller = controller;
		
		setUsePhysics(true);
		
		setWorldSize((float)24.9);
		
		Character character = new Character(new Vector3d(0, 0, 0), "Le tueur");
		add(character);
		for (int i = 0; i < 5; i++) {
			add(new Zombie(new Vector3d((int)(Math.random()* 10), 0, (int)(Math.random()* 10)), "Le tueur", character, this));
		}
		
	}
	
	
	public void testRound() {
		Simulator simu = controller.getSimulator();
		ArrayList<Object> robot = simu.getAgentList();
		boolean test = true;
		
		
		//if(test) { controller.upRound(); }
	}

}