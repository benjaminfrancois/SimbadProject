/*
 * Created on 23 mars 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package simbad.sim;

/**
 * @author louis
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Geometry  {

    
    
    
  /*  
    public boolean sphereRectangleContact(double radius, double center[],double rect[],Vector3d normal[]){
        
        // compute rectangle normal -- points are counterclockwize
        // N = (P2-P1) crossProd (P3-P1) / Lenght((P2-P1) crossProd (P3-P1)) 
         double p1x = rect[0];
         double p1y = rect[1];
         double p1z = rect[2];
         
         double v1x = rect[3*1] - p1x;
         double v1y = rect[3*1+1] - p1y;
         double v1z = rect[3*1+2] - p1z;
         double v2x = rect[3*1] - p1x;
         double v2y = rect[3*1+1] - p1y;
         double v2z = rect[3*1+2] - p1z;
         
         n[0] = 
        return true;
    }*/
}
